// background.js (MV3 service worker)
// Handles control messages from popup and relays to active tab content script

const STATE_KEY = 'plugin_rec_pro_state';

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

async function setState(patch) {
  const cur = (await chrome.storage.local.get(STATE_KEY))[STATE_KEY] || { recording: false, actionsCount: 0 };
  const next = { ...cur, ...patch };
  await chrome.storage.local.set({ [STATE_KEY]: next });
  return next;
}

function isScriptableUrl(url) {
  if (!url) return false;
  // Disallow system/extension pages where content scripts cannot run
  return !/^(chrome:\/\/|edge:\/\/|about:|chrome-extension:\/\/)/i.test(url);
}

async function ensureContentScript(tabId) {
  try {
    // ping: if a receiver exists, this resolves; otherwise it throws
    await chrome.tabs.sendMessage(tabId, { type: 'rec:ping' });
    return true;
  } catch (e) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId, allFrames: true },
        files: ['content-script.js']
      });
      // give it a short moment to initialize
      await new Promise(r => setTimeout(r, 50));
      return true;
    } catch (e2) {
      console.warn('Failed to inject content-script.js', e2);
      return false;
    }
  }
}

async function sendToTab(tab, message) {
  if (!tab?.id) throw new Error('No active tab');
  if (!isScriptableUrl(tab.url)) throw new Error('Active tab URL is not scriptable');
  const ok = await ensureContentScript(tab.id);
  if (!ok) throw new Error('Could not inject content script');
  return chrome.tabs.sendMessage(tab.id, message);
}

chrome.runtime.onInstalled.addListener(() => {
  setState({ recording: false, actionsCount: 0 });
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    if (!msg || !msg.type) return;

    if (msg.type === 'getStatus') {
      const st = (await chrome.storage.local.get(STATE_KEY))[STATE_KEY] || { recording: false, actionsCount: 0 };
      sendResponse({ ok: true, state: st });
      return;
    }

    if (msg.type === 'startRecording') {
      const tab = await getActiveTab();
      try {
        await sendToTab(tab, { type: 'rec:start' });
      } catch (e) {
        return sendResponse({ ok: false, error: String(e.message || e) });
      }
      const st = await setState({ recording: true });
      sendResponse({ ok: true, state: st });
      return;
    }

    if (msg.type === 'stopRecording') {
      const tab = await getActiveTab();
      try {
        await sendToTab(tab, { type: 'rec:stop' });
      } catch (e) {
        return sendResponse({ ok: false, error: String(e.message || e) });
      }
      const st = await setState({ recording: false });
      sendResponse({ ok: true, state: st });
      return;
    }

    if (msg.type === 'playRecording') {
      const tab = await getActiveTab();
      try {
        await sendToTab(tab, { type: 'rec:play' });
      } catch (e) {
        return sendResponse({ ok: false, error: String(e.message || e) });
      }
      sendResponse({ ok: true });
      return;
    }

    if (msg.type === 'clearRecording') {
      await chrome.storage.local.remove('plugin_rec_pro_actions');
      const st = await setState({ actionsCount: 0 });
      const tab = await getActiveTab();
      if (tab?.id) {
        try { await sendToTab(tab, { type: 'rec:cleared' }); } catch (_) {}
      }
      sendResponse({ ok: true, state: st });
      return;
    }
  })();
  return true; // keep channel open for async sendResponse
});

// Keep actionsCount in sync when content-script updates it
chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === 'rec:count') {
    setState({ actionsCount: msg.count });
  }
});
