// popup.js

const elRec = document.getElementById('rec');
const elCount = document.getElementById('count');
const btnStart = document.getElementById('start');
const btnStop = document.getElementById('stop');
const btnPlay = document.getElementById('play');
const btnClear = document.getElementById('clear');
const inStepDelay = document.getElementById('stepDelay');
const inFindTimeout = document.getElementById('findTimeout');
const btnExport = document.getElementById('export');
const btnImport = document.getElementById('import');
const inImportFile = document.getElementById('importFile');

const ACTIONS_KEY = 'plugin_rec_pro_actions';
const SETTINGS_KEY = 'plugin_rec_pro_settings';

function setStatus(st) {
  if (!st) return;
  elRec.textContent = String(!!st.recording);
  elCount.textContent = String(st.actionsCount || 0);
}

function getStatus() {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: 'getStatus' }, (res) => {
      resolve(res?.state || { recording: false, actionsCount: 0 });
    });
  });
}

async function refresh() {
  const st = await getStatus();
  setStatus(st);
  // load settings
  const obj = await chrome.storage.local.get(SETTINGS_KEY);
  const s = obj[SETTINGS_KEY] || {};
  inStepDelay.value = (typeof s.stepDelay === 'number' ? s.stepDelay : 300);
  inFindTimeout.value = (typeof s.findTimeout === 'number' ? s.findTimeout : 3000);
}

btnStart.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'startRecording' }, (res) => {
    if (res?.state) setStatus(res.state);
  });
});

btnStop.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'stopRecording' }, (res) => {
    if (res?.state) setStatus(res.state);
  });
});

btnPlay.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'playRecording' });
});

btnClear.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'clearRecording' }, (res) => {
    if (res?.state) setStatus(res.state);
  });
});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === 'rec:count') {
    elCount.textContent = String(msg.count || 0);
  }
});

function saveSettings() {
  const stepDelay = Number(inStepDelay.value) || 0;
  const findTimeout = Number(inFindTimeout.value) || 0;
  chrome.storage.local.set({ [SETTINGS_KEY]: { stepDelay, findTimeout } });
}

inStepDelay.addEventListener('change', saveSettings);
inFindTimeout.addEventListener('change', saveSettings);

async function exportActions() {
  const obj = await chrome.storage.local.get(ACTIONS_KEY);
  const actions = obj[ACTIONS_KEY] || [];
  const blob = new Blob([JSON.stringify(actions, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'plugin-rec-pro-actions.json';
  a.click();
  URL.revokeObjectURL(url);
}

btnExport.addEventListener('click', exportActions);

btnImport.addEventListener('click', () => inImportFile.click());

inImportFile.addEventListener('change', async () => {
  const file = inImportFile.files && inImportFile.files[0];
  if (!file) return;
  try {
    const text = await file.text();
    const data = JSON.parse(text);
    if (!Array.isArray(data)) throw new Error('Invalid JSON format');
    await chrome.storage.local.set({ [ACTIONS_KEY]: data });
    chrome.runtime.sendMessage({ type: 'rec:count', count: data.length });
  } catch (e) {
    console.error('Import failed', e);
  } finally {
    inImportFile.value = '';
  }
});

refresh();
